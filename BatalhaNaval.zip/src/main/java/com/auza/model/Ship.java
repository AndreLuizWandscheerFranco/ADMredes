package com.auza.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Ship implements Serializable {
    private String name;
    private int size;
    private Set<Coordinate> coords = new HashSet<>();
    private Set<Coordinate> hits = new HashSet<>();

    public Ship(String name, int size) {
        this.name = name;
        this.size = size;
    }

    public String getName() { return name; }
    public int getSize() { return size; }
    public Set<Coordinate> getCoords() { return coords; }
    public Set<Coordinate> getHits() { return hits; }

    public void addCoordinate(Coordinate c) { coords.add(c); }

    public boolean contains(Coordinate c) { return coords.contains(c); }

    public boolean registerHit(Coordinate c) {
        if (coords.contains(c)) {
            hits.add(c);
            return true;
        }
        return false;
    }

    public boolean isSunk() {
        return hits.size() >= coords.size();
    }
}
