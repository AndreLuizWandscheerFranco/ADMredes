package com.auza.model;

import java.io.Serializable;
import java.util.*;

public class Board implements Serializable {
    private int size;
    private List<Ship> ships = new ArrayList<>();
    private Set<Coordinate> shots = new HashSet<>();

    public Board(int size) { this.size = size; }

    public int getSize() { return size; }
    public List<Ship> getShips() { return ships; }
    public Set<Coordinate> getShots() { return shots; }

    public boolean alreadyShot(Coordinate c) { return shots.contains(c); }

    public void addShot(Coordinate c) { shots.add(c); }

    public void addShip(Ship s) { ships.add(s); }

    public Optional<Ship> shipAt(Coordinate c) {
        return ships.stream().filter(s -> s.contains(c)).findFirst();
    }

    public boolean allSunk() {
        return ships.stream().allMatch(Ship::isSunk);
    }

    // Try to place a ship randomly on board without overlapping
    public boolean placeShipRandomly(Ship ship, Random rnd) {
        int attempts = 0;
        while (attempts < 1000) {
            attempts++;
            boolean horizontal = rnd.nextBoolean();
            int maxX = horizontal ? size - ship.getSize() : size - 1;
            int maxY = horizontal ? size - 1 : size - ship.getSize();
            int startX = rnd.nextInt(maxX + 1);
            int startY = rnd.nextInt(maxY + 1);
            List<Coordinate> coords = new ArrayList<>();
            for (int i = 0; i < ship.getSize(); i++) {
                int x = startX + (horizontal ? i : 0);
                int y = startY + (horizontal ? 0 : i);
                coords.add(new Coordinate(x,y));
            }
            boolean conflict = coords.stream().anyMatch(c -> shipAt(c).isPresent());
            if (!conflict) {
                coords.forEach(ship::addCoordinate);
                ships.add(ship);
                return true;
            }
        }
        return false;
    }
}
