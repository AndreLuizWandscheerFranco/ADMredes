package com.auza.view;

import com.auza.service.JogoRMI;

import javax.swing.*;
import java.awt.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.HashSet;
import java.util.Set;

public class TelaJogo extends JFrame {

    private JPanel painelJogador;
    private JPanel painelInimigo;
    private JTextArea areaMensagens;
    private JButton btnIniciar;
    private JButton btnReiniciar;
    private JogoRMI jogo;
    private String playerName = "Jogador1";

    private Set<String> inimigoAtirado = new HashSet<>(); // to prevent local double-clicks
    private boolean partidaFinalizada = false;

    public TelaJogo() {
        setTitle("Batalha Naval");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // centraliza
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(15, 23, 42)); // azul marinho escuro

        painelJogador = criarGrade("Seu Tabuleiro", true);
        painelInimigo = criarGrade("Tabuleiro Inimigo", false);

        areaMensagens = new JTextArea(7, 30);
        areaMensagens.setEditable(false);
        areaMensagens.setBackground(new Color(241, 245, 249));
        areaMensagens.setFont(new Font("Consolas", Font.PLAIN, 14));
        areaMensagens.setBorder(BorderFactory.createTitledBorder("Mensagens"));

        btnIniciar = new JButton("Iniciar Jogo (Registrar no servidor)");
        btnReiniciar = new JButton("Reiniciar");
        JPanel painelBotoes = new JPanel();
        painelBotoes.setBackground(new Color(15, 23, 42));
        painelBotoes.add(btnIniciar);
        painelBotoes.add(btnReiniciar);

        JPanel painelGrades = new JPanel(new GridLayout(1, 2, 20, 0));
        painelGrades.setBackground(new Color(15, 23, 42));
        painelGrades.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        painelGrades.add(painelJogador);
        painelGrades.add(painelInimigo);

        add(painelGrades, BorderLayout.CENTER);
        add(new JScrollPane(areaMensagens), BorderLayout.SOUTH);
        add(painelBotoes, BorderLayout.NORTH);

        // actions
        btnIniciar.addActionListener(e -> {
            try {
                Registry registry = LocateRegistry.getRegistry("localhost", 1099);
                jogo = (JogoRMI) registry.lookup("JogoBatalha");
                String r = jogo.registrarJogador(playerName);
                areaMensagens.append("Servidor: " + r + "\n");
                partidaFinalizada = false;
                inimigoAtirado.clear();
                resetButtons();
            } catch (Exception ex) {
                areaMensagens.append("Erro ao conectar/registrar: " + ex.getMessage() + "\n");
            }
        });

        btnReiniciar.addActionListener(e -> {
            try {
                if (jogo != null) {
                    String r = jogo.reiniciarPartida(playerName);
                    areaMensagens.append("Servidor: " + r + "\n");
                    partidaFinalizada = false;
                    inimigoAtirado.clear();
                    resetButtons();
                }
            } catch (Exception ex) {
                areaMensagens.append("Erro ao reiniciar: " + ex.getMessage() + "\n");
            }
        });
    }

    private JPanel criarGrade(String titulo, boolean jogador) {
        JPanel painel = new JPanel(new GridLayout(10, 10));
        painel.setBorder(BorderFactory.createTitledBorder(titulo));
        painel.setBackground(Color.WHITE);

        for (int i = 0; i < 100; i++) {
            JButton botao = new JButton();
            botao.setPreferredSize(new Dimension(40, 40));
            botao.setBackground(new Color(203, 213, 225));
            botao.setFocusPainted(false);
            final int index = i;
            botao.addActionListener(evt -> {
                int linha = index / 10;
                int coluna = index % 10;
                if (partidaFinalizada) return;
                if (!jogador) { // atacando inimigo
                    String key = linha + "," + coluna;
                    if (inimigoAtirado.contains(key)) {
                        areaMensagens.append("Já atirou nessa posição: " + key + "\n");
                        return;
                    }
                    inimigoAtirado.add(key);
                    areaMensagens.append("Atacando: (" + linha + "," + coluna + ")\n");
                    if (jogo != null) {
                        try {
                            String resp = jogo.realizarJogada(linha, coluna, playerName);
                            areaMensagens.append("Servidor respondeu: " + resp + "\n");
                            processarResposta(resp, botao);
                        } catch (Exception ex) {
                            areaMensagens.append("Erro ao enviar jogada: " + ex.getMessage() + "\n");
                        }
                    } else {
                        areaMensagens.append("Não conectado ao servidor. Clique em Iniciar Jogo.\n");
                    }
                } else {
                    areaMensagens.append("Este tabuleiro é seu; os navios estão posicionados aleatoriamente pelo servidor.\n");
                }
            });
            painel.add(botao);
        }

        return painel;
    }

    private void processarResposta(String resp, JButton botao) {
        if (resp.startsWith("JA_ATIRADO")) {
            areaMensagens.append("Aviso: já atirado nessa posição no servidor.\n");
            return;
        }
        if (resp.startsWith("AGUA")) {
            botao.setText("O"); // água
            botao.setEnabled(false);
            if (resp.contains(";AI:")) {
                String aiPart = resp.substring(resp.indexOf(";AI:")+4);
                areaMensagens.append("Ação AI: " + aiPart + "\n");
                if (aiPart.contains("AI_VENCEU")) {
                    partidaFinalizada = true;
                    areaMensagens.append("AI venceu a partida. Você perdeu.\n");
                    disableAllButtons();
                }
            }
            return;
        }
        if (resp.startsWith("FOGO")) {
            botao.setText("X"); // hit
            botao.setEnabled(false);
            areaMensagens.append("Acertou! Você pode jogar novamente.\n");
            return;
        }
        if (resp.startsWith("AFUNDOU")) {
            String[] parts = resp.split(";");
            String sunkPart = parts[0];
            String shipName = sunkPart.substring(sunkPart.indexOf(":")+1);
            botao.setText("X");
            botao.setEnabled(false);
            areaMensagens.append("Afundou o navio: " + shipName + "\n");
            if (resp.contains("RESULT:VENCEU")) {
                partidaFinalizada = true;
                areaMensagens.append("Você venceu! Todos os navios inimigos foram destruídos.\n");
                disableAllButtons();
            }
            return;
        }
        if (resp.startsWith("ERROR:")) {
            areaMensagens.append("Erro do servidor: " + resp + "\n");
            return;
        }
        areaMensagens.append("Resposta desconhecida: " + resp + "\n");
    }

    private void resetButtons() {
        Component[] comps = painelInimigo.getComponents();
        for (Component c : comps) {
            if (c instanceof JButton) {
                JButton b = (JButton)c;
                b.setEnabled(true);
                b.setText(""); 
                b.setBackground(new Color(203,213,225));
            }
        }
    }

    private void disableAllButtons() {
        Component[] comps = painelInimigo.getComponents();
        for (Component c : comps) {
            if (c instanceof JButton) {
                JButton b = (JButton)c;
                b.setEnabled(false);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new TelaJogo().setVisible(true);
        });
    }
}
