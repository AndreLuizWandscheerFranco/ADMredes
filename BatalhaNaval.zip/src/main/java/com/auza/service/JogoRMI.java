package com.auza.service;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface JogoRMI extends Remote {
    String registrarJogador(String nome) throws RemoteException;
    String realizarJogada(int x, int y, String jogador) throws RemoteException;
    String obterStatusPartida(String jogador) throws RemoteException;
    String reiniciarPartida(String jogador) throws RemoteException;
}
