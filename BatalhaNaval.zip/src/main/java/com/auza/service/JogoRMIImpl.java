package com.auza.service;

import com.auza.model.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class JogoRMIImpl extends UnicastRemoteObject implements JogoRMI {

    private static final int BOARD_SIZE = 10;
    private static final List<ShipSpec> FLEET = Arrays.asList(
            new ShipSpec("Porta-aviões",5),
            new ShipSpec("Encouraçado",4),
            new ShipSpec("Submarino",3),
            new ShipSpec("Cruzador",3),
            new ShipSpec("Destroier",2)
    );

    private Map<String, GameState> games = new HashMap<>(); // playerName -> GameState
    private Random rnd = new Random();

    protected JogoRMIImpl() throws RemoteException { super(); }

    @Override
    public synchronized String registrarJogador(String nome) throws RemoteException {
        if (games.containsKey(nome)) {
            games.remove(nome); // reset existing
        }
        GameState gs = new GameState();
        gs.playerBoard = createBoardWithFleet();
        gs.aiBoard = createBoardWithFleet();
        gs.currentTurn = nome; // player starts
        gs.playerTurn = nome;
        games.put(nome, gs);
        return "OK:Registrado e partida iniciada.";
    }

    @Override
    public synchronized String realizarJogada(int x, int y, String jogador) throws RemoteException {
        GameState gs = games.get(jogador);
        if (gs == null) return "ERROR:Jogador não registrado.";
        if (gs.gameOver) return "ERROR:Partida finalizada.";
        Coordinate c = new Coordinate(x,y);
        // Player shoots at AI board
        if (gs.playerTurn != null && !gs.playerTurn.equals(jogador)) {
            return "ERROR:Não é sua vez.";
        }
        if (gs.aiBoard.alreadyShot(c)) {
            return "JA_ATIRADO";
        }
        gs.aiBoard.addShot(c);
        Optional<Ship> shipOpt = gs.aiBoard.shipAt(c);
        if (!shipOpt.isPresent()) {
            // Agua
            gs.playerTurn = null;
            StringBuilder resp = new StringBuilder("AGUA");
            // After water, AI shoots once
            String aiResp = aiPlay(gs);
            // Check if AI won
            if (gs.playerBoard.allSunk()) {
                gs.gameOver = true;
                return resp.append(";AI:").append(aiResp).append(";RESULT:AI_VENCEU").toString();
            }
            return resp.append(";AI:").append(aiResp).toString();
        } else {
            Ship s = shipOpt.get();
            s.registerHit(c);
            if (s.isSunk()) {
                if (gs.aiBoard.allSunk()) {
                    gs.gameOver = true;
                    return "AFUNDOU:" + s.getName() + ";RESULT:VENCEU";
                } else {
                    return "AFUNDOU:" + s.getName();
                }
            } else {
                return "FOGO";
            }
        }
    }

    @Override
    public synchronized String obterStatusPartida(String jogador) throws RemoteException {
        GameState gs = games.get(jogador);
        if (gs == null) return "ERROR:Jogador não registrado.";
        if (gs.gameOver) return "FINALIZADA";
        return "EM_ANDAMENTO";
    }

    @Override
    public synchronized String reiniciarPartida(String jogador) throws RemoteException {
        games.remove(jogador);
        return registrarJogador(jogador);
    }

    private Board createBoardWithFleet() {
        Board b = new Board(BOARD_SIZE);
        for (ShipSpec spec : FLEET) {
            Ship ship = new Ship(spec.name, spec.size);
            boolean ok = b.placeShipRandomly(ship, rnd);
            if (!ok) {
                b = new Board(BOARD_SIZE);
                for (ShipSpec s2 : FLEET) {
                    Ship sh = new Ship(s2.name, s2.size);
                    b.placeShipRandomly(sh, rnd);
                }
                return b;
            }
        }
        return b;
    }

    private String aiPlay(GameState gs) {
        int attempts = 0;
        while (attempts < 1000) {
            attempts++;
            int x = rnd.nextInt(BOARD_SIZE);
            int y = rnd.nextInt(BOARD_SIZE);
            Coordinate c = new Coordinate(x,y);
            if (gs.playerBoard.alreadyShot(c)) continue;
            gs.playerBoard.addShot(c);
            Optional<Ship> shipOpt = gs.playerBoard.shipAt(c);
            if (!shipOpt.isPresent()) {
                return "AI_ATIROU:" + x + "," + y + ":AGUA";
            } else {
                Ship s = shipOpt.get();
                s.registerHit(c);
                if (s.isSunk()) {
                    if (gs.playerBoard.allSunk()) {
                        gs.gameOver = true;
                        return "AI_ATIROU:" + x + "," + y + ":AFUNDOU:" + s.getName() + ":AI_VENCEU";
                    } else {
                        return "AI_ATIROU:" + x + "," + y + ":AFUNDOU:" + s.getName();
                    }
                } else {
                    return "AI_ATIROU:" + x + "," + y + ":FOGO";
                }
            }
        }
        return "AI_PASSOU";
    }

    private static class GameState {
        Board playerBoard;
        Board aiBoard;
        boolean gameOver = false;
        String currentTurn;
        String playerTurn;
    }

    private static class ShipSpec {
        String name; int size;
        ShipSpec(String n,int s){ name=n; size=s; }
    }
}
