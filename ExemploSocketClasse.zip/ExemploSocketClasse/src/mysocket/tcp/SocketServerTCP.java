package mysocket.tcp;

import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class SocketServerTCP {

	public static void main(String[] args) {
		try {
			 ServerSocket servidor = new ServerSocket(1025);
			 System.out.println("Servidor iniciado na porta: "+servidor.getLocalPort());
			
			 while (true) {
				 Socket cliente = servidor.accept();
				 
				 System.out.println("Cliente: "+cliente.getPort()+" "+cliente.getLocalAddress());
				 
				 ObjectOutputStream saida = new ObjectOutputStream(cliente.getOutputStream());
				 saida.flush();
				 saida.writeObject(new Date());
				 
				 saida.close();
				 cliente.close();
			 }
		} catch (Exception e) {
			System.out.println("Ocorreu um erro: "+e.getMessage());
		}

	}

}
