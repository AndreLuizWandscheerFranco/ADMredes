package mysocket.tcp;

import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.Date;


public class ClienteSocketTCP {
	public static void main(String[] args) {
		try {
			Socket cliente = new Socket("localhost",1025);
			
			ObjectInputStream entrada = new ObjectInputStream(cliente.getInputStream());
			
			Date dataServidor = (Date)entrada.readObject();
			
			System.out.println("Data do servidor: "+dataServidor.toString());
			
			entrada.close();
			
		}catch(Exception e) {
			System.out.println("Ocorreu um erro: "+e.getMessage());
		}
	}
}
