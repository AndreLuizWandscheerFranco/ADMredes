package mysocket.udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class SocketClientUDP {

	public static void main(String[] args) {
		try {
			DatagramSocket cliente = new DatagramSocket();
			
			System.out.println("Serviço socket UDP ativo.");
			
			String mensagem = "Olá pessoal!";
			
			DatagramPacket segmento = 
					new DatagramPacket(mensagem.getBytes(), mensagem.getBytes().length, InetAddress.getByName("localhost"), 1026);
			
			System.out.println("A mensagem foi enviada pela porta: "+cliente.getLocalPort());
			
			cliente.send(segmento);
			
			cliente.close();
		} catch(Exception e) {
			System.out.println("Ocorreu um erro: "+e.getMessage());
		}

	}

}
