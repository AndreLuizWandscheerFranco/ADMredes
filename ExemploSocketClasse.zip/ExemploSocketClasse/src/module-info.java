/**
 * 
 */
/**
 * 
 */
module ExemploSocketClasse {
}